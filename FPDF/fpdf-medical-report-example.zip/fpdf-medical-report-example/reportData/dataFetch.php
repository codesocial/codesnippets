<?php
$row = 1;
$flag = true;
//$patientID = "PAT1110111DR1";
$patientID = $patientid;
if (($handle = fopen("reportData/reportData.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        if($flag) { $flag = false; continue; }
            if($data[0] == $patientID){
                $PatientLastNames = $data[3];
                $PatientFirstNames = $data[4];
                $PatientMiddleNames = $data[5];
                $reportType = $data[2];
                $reportDateTime = $data[1];
                $findingsLine1 = $data[6];
                $findingsLine2 = $data[7];
                $findingsLine3 = $data[8];
                $findingsLine4 = $data[9];
                $findingsLine5 = $data[10];
                $conclusionLine1 = $data[11];
                $conclusionLine2 = $data[12];
                $conclusionLine3 = $data[13];
                $conclusionLine4 = $data[14];
                $conclusionLine5 = $data[15];
        }
    }
                
    fclose($handle);
}
?>