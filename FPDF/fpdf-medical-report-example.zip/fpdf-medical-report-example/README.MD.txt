On Windows
Setup IIS Server with FastCGI Module (https://jamesmccaffrey.wordpress.com/2017/01/26/installing-php-on-windows-10-and-iis/)
Install PHP

On Linux
Setup apache webserver and php or LAMP stack

Copy the code to public_html or wwwroot directory and open index.html in browser.

Example : 
Fetch report where ID = PAT1110111DR1 on button click.
ID is fetched from csv file.
You can connect any database and modify dataFetch.php accordingly with search query.

