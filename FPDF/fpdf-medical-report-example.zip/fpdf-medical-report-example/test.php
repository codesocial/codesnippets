<?php
//import libraries for pdf and barcode
require('fpdf/fpdf.php');
require('phpbarcode/phpbarcode.php');
$patientid = $_GET['patientID'];
//import data from csv
require('reportData/dataFetch.php');

$pdf = new FPDF();
$pdf = new PDF_BARCODE('P','mm','A4');
$pdf->AddPage();
$pdf->EAN13(155,20,'012345678901', 5, 0.35, 9);
$pdf->SetFont('Arial','B',16);
$pdf->Rect(10,10,190,250);
//set project name here
$reportTitle = 'Detection of thoracic diseases from chest x-ray';
$pdf->SetX(85);
$pdf->Cell(40,10,$reportTitle,0,0,'C');
//set subtitle
$pdf->SetY(30);
$pdf->SetFont('Arial','U',12);
$pdf->Cell(190,0,"Diagnosis Report",0,0,'C');

//set report header title
$pdf->SetXY(10,40);
$pdf->SetFont('Arial','',10);
$pdf->SetFillColor(200,220,255);
$pdf->Cell(65,7,'Personal Details',1,0,'',1);
$pdf->Cell(65,7,'Report Type',1,0,'',1);
$pdf->Cell(60,7,'Date',1,0,'',1);
$pdf->SetXY(13,55);
$pdf->Cell(40,10,$patientid,0,0,'');
$pdf->SetXY(13,50);


//set header row data
//set patient name
//$patientID = 'PAT1101111';
//$PatientLastNames = 'Last';
//$PatientFirstNames = 'First';
//$PatientMiddleNames = 'Middle';
$patientdata = $PatientLastNames." ".$PatientFirstNames." ".$PatientMiddleNames;
///set QR code with patientID
$pdf->Image("http://localhost/report/phpqrcode/qr_generator.php?code=$patientID", 12, 12, 25, 25, "png");
//set barcode



//set report type
//$reportType = 'Report 1';
//set date and time
date_default_timezone_set("Asia/Kolkata");
//$reportDateTime = date('d-m-Y')." ".date("h:i:sa");
$pdf->Cell(65,7,$patientdata,0,0,'');
$pdf->Cell(65,7,$reportType,0,0,'');
$pdf->Cell(65,7,$reportDateTime,0,0,'');

//set report details
//set findings
$findingsTitle = 'Findings';
//$findingsLine1 = 'finding line1';
//$findingsLine2 = 'finding line2';
//$findingsLine3 = 'finding line3';
//$findingsLine4 = 'finding line4';
//$findingsLine5 = 'finding line5';
$findingsText = $findingsLine1."\n".$findingsLine2."\n".$findingsLine3."\n".$findingsLine4."\n".$findingsLine5;
$pdf->SetXY(10,80);
$pdf->SetFillColor(200,220,255);
$pdf->Cell(190,7,$findingsTitle,1,0,'',1);
$pdf->SetXY(13,90);
//$pdf->Cell(190,7,$findingsText,0,0,'');
$pdf->Multicell(190,7,$findingsText); 
//set conclusion
$conclusionTitle = 'Conclusion';
//$conclusionLine1 = 'conclusion line1';
//$conclusionLine2 = 'conclusion line2';
//$conclusionLine3 = 'conclusion line3';
//$conclusionLine4 = 'conclusion line4';
//$conclusionLine5 = 'conclusion line5';
$conclusionText = $conclusionLine1."\n".$conclusionLine2."\n".$conclusionLine3."\n".$conclusionLine4."\n".$conclusionLine5;
$pdf->SetXY(10,140);
$pdf->SetFillColor(200,220,255);
$pdf->Cell(190,7,$conclusionTitle,1,0,'',1);
$pdf->SetXY(13,150);
$pdf->Multicell(190,7,$conclusionText); 


//set footer
$pdf->SetXY(10,230);
$signHereSpace = '_______';
$doc1Name = 'Doc 1'; 
$doc1Deg = 'Deg';
$doc1 = $signHereSpace."\n".$doc1Name."\n".$doc1Deg;
$doc2Name = 'Doc 2'; 
$doc2Deg = 'Deg';
$doc2 = $signHereSpace."\n".$doc2Name."\n".$doc2Deg;
$doc3Name = 'Doc 3'; 
$doc3Deg = 'Deg';
$doc3 = $signHereSpace."\n".$doc3Name."\n".$doc3Deg;
$pdf->SetXY(20,230);
$pdf->Multicell(190,7,$doc1);
$pdf->SetXY(100,230);
$pdf->Multicell(190,7,$doc2);
$pdf->SetXY(175,230);
$pdf->Multicell(190,7,$doc3);
$pdf->SetFont('Arial','',8);
$pdf->SetXY(10,260);
$pdf->SetFillColor(200,220,255);
$pdf->Cell(190,10,'Thank You',1,0,'C',1);
$fileName = 'report'."-".$patientID.".pdf";
$pdf->Output("D",$fileName);
//$pdf->Output();
?>